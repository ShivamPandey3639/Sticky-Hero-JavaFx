# Sticky-Hero-JavaFx
Creating Sticky Hero game using JavaFx
