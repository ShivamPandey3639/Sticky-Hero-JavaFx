package com.example.stickhero;

import javafx.animation.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.transform.Rotate;
import javafx.util.Duration;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Character {
    private ImageView character;

    public Character(ImageView character) {
        this.character = character;
        character.setX(150);
        character.setY(550);
    }

    public void resetCharacterPostion(Pillar pillar) {
        double newX = pillar.getP1().getX() + (pillar.getP1().getWidth() / 2) - (character.getFitWidth() / 2);
        double newY = 550;
        System.out.println(pillar.getP1().getX() + (pillar.getP1().getWidth() / 2) - (character.getFitWidth() / 2));

        character.setX(newX);
//        character.setY(newY);

        // Clear any previous transformations
        character.getTransforms().clear();
    }


    public void moveForward(Platform platform, Pillar pillar, Score scoreKeeper) {
        double moveToX = platform.getHeight();
        double currentX = character.getTranslateX();

//        double distanceToMove = moveToX - currentX;
        double speed = 200;
        double distanceToMove = platform.getHeight() + (pillar.getP1().getWidth() / 2);
        Duration duration = Duration.seconds(distanceToMove / speed);


        TranslateTransition translateTransition = new TranslateTransition(duration, character);
        translateTransition.setByX(distanceToMove);
        translateTransition.setInterpolator(Interpolator.LINEAR);

        translateTransition.setOnFinished(actionEvent -> {
            if (platform.getHeight() > (pillar.getP2().getX() - pillar.getP1().getX() + pillar.getP2().getWidth() - pillar.getP1().getWidth()) ||
                    (platform.getHeight() < (pillar.getP2().getX() - pillar.getP1().getX() - pillar.getP1().getWidth()))) {
                fallDown();
            } else {
                //update score here

                pillar.movePillars();
                resetCharacterPostion(pillar);
                platform.resetPlatform(pillar);

                scoreKeeper.updateScore();
                try {
                    ScoreCheck();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });

        translateTransition.play();
    }
    public void ScoreCheck() throws IOException {
        PrintWriter fp = new PrintWriter(new FileWriter("in.txt"));
        fp.println(Score.getPoints());
        fp.close();
    }

    public void flippingDown() {
        double pivotX = character.getX() + character.getFitWidth() / 2.0;
        double pivotY = character.getY() + character.getFitHeight();

        Rotate rotate = new Rotate(180, pivotX, pivotY);
        character.getTransforms().add(rotate);
    }

    public void fallDown() {
        RotateTransition rotateTransition = new RotateTransition(Duration.seconds(1), character);
        rotateTransition.setByAngle(360);
        rotateTransition.setCycleCount(1);


        TranslateTransition translateTransition = new TranslateTransition(Duration.seconds(1), character);
        translateTransition.setByY(200);
        translateTransition.setCycleCount(1);


        ParallelTransition fallTransition = new ParallelTransition(rotateTransition, translateTransition);
        fallTransition.setOnFinished(event -> {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("gameOver.fxml"));
            Parent root = null;
            try {
                root = loader.load();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Scene scene = new Scene(root);

            FXMLManager.getInstance().getStage().setScene(scene);
            Controller gameScreenController = (Controller) loader.getController();
            try {
                gameScreenController.initializeGameOver();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        fallTransition.play();
    }

}
