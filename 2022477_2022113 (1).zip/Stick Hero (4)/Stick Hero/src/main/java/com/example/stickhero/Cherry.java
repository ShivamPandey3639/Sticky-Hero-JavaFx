package com.example.stickhero;

import javafx.scene.image.ImageView;

import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Cherry {
    private static int count;
    private ImageView cherry;

    public Cherry(int count) {
        Cherry.count = count;
    }

    public Cherry(ImageView cherry) {
        this.cherry = cherry;
        count = 0;
    }

    public static int getCount() {
        return count;
    }

    public void buyCherry(int no) {
    }

    public void increment(int no) {
    }

    public void decrement(int no) {
    }

    public void generateCherry(Pillar pillar) {
        Random random = new Random();

        double minX = pillar.getP1().getX() + pillar.getP1().getWidth() + 5;
        double maxX = pillar.getP2().getX() - 5;


        double randomPositionX = minX + (maxX - minX) * random.nextDouble();


        cherry.setX(randomPositionX);
        cherry.setY(600 + 20);
    }

    public void detectCherry(ImageView character){
        ScheduledExecutorService collisionDetectionExecutor = Executors.newScheduledThreadPool(1);
        collisionDetectionExecutor.scheduleAtFixedRate(() -> {
            // Check for collisions
            if (character.getBoundsInParent().intersects(cherry.getBoundsInParent())) {
                System.out.println("Collision detected!");
            }
        }, 0, 16, TimeUnit.MILLISECONDS);
    }
}
