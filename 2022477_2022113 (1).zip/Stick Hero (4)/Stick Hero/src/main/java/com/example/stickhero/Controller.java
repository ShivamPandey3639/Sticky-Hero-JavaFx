package com.example.stickhero;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Controller {
    public Pillar pillar;
    public Platform platform;
    public Character mainCharacter;
    public Score scoreKeeper;
    @FXML
    private StackPane overlayPane;
    @FXML
    private AnchorPane main;
    @FXML
    private VBox mainContainer;
    @FXML
    private Label titleLabel;
    @FXML
    private Button playButton;
    @FXML
    private Button characterButton;
    @FXML
    private Button soundButton;
    @FXML
    private Button helpButton;
    @FXML
    private Button cheatButton;
    @FXML
    private Label scoreLabel;
    @FXML
    private Label cherryLabel;
    @FXML
    private Button button;
    @FXML
    private Rectangle pillar1;
    @FXML
    private Rectangle pillar2;
    @FXML
    private Rectangle pillar3;
    @FXML
    private Rectangle bridge;
    @FXML
    private ImageView character;
    @FXML
    private Label retryScore;
    @FXML
    private Label retryBest;
    @FXML
    private Button homeButton;
    @FXML
    private Button retryButton;
    private boolean spacebarPressed = false;


    @FXML
    public void handlePlayButton() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("GameScreen.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);

        FXMLManager.getInstance().getStage().setScene(scene);
        Controller gameScreenController = (Controller) loader.getController();
        gameScreenController.initializeWithPillars();
//        initializeWithPillars();
    }

    @FXML
    public void handleCharacterButton() throws IOException {
        switchScene("characterOverlay.fxml");
    }

    @FXML
    public void handleRetryButton() throws IOException {
        //setup this  shit
        FXMLLoader loader = new FXMLLoader(getClass().getResource("GameScreen.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);

        FXMLManager.getInstance().getStage().setScene(scene);
        Controller gameScreenController = (Controller) loader.getController();
        gameScreenController.initializeWithPillars();

    }

    @FXML
    public void closeOverlay() throws IOException {
        FXMLManager.getInstance().getStage().setScene(FXMLManager.getInstance().loadFXML("HomeScreen.fxml"));
    }
//FactoryDesign below
    @FXML
    public void handleSoundButton(ActionEvent e) throws InterruptedException {
        // Handle sound button action
        if (e.getSource() == soundButton) {
            FactorySound fs=new FactorySound();
            Sound soundInterface= (Sound) fs.getSound("homesound");
            soundInterface.start();
            soundInterface.join();


        }
    }

    @FXML
    public void handleHelpButton() {
        // Handle help button action
        System.out.println("help");
    }

    @FXML
    public void handleCheatButton() {
        // Handle score button action
        System.out.println("cheat");
    }

    @FXML
    public void initialize() throws IOException {

    }

    public void initializeGameOver() throws IOException {

        retryScore.setText("SCORE: " + Score.getPoints());
        retryBest.setText("BEST: " + Score.getHighScore());
    }

    public void initializeWithPillars() throws IOException {
        if (pillar1 != null && pillar2 != null && pillar3 != null)
            this.pillar = new Pillar(pillar1, pillar2, pillar3);

        if (bridge != null)
            this.platform = new Platform(bridge, pillar);

        if (character != null)
            this.mainCharacter = new Character(character);

        if (scoreLabel != null && cherryLabel != null)
            this.scoreKeeper = new Score(scoreLabel, cherryLabel);

        mainCharacter.resetCharacterPostion(pillar);
        platform.resetPlatform(pillar);
        PrintWriter fp = new PrintWriter(new FileWriter("in.txt"));
        fp.println(Score.getPoints());
        fp.close();

        EventHandler<KeyEvent> keyEventHandler = new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent event) {
                if (event.getCode() == javafx.scene.input.KeyCode.SPACE) {
                    if (event.getEventType() == KeyEvent.KEY_PRESSED) {
                        // Spacebar pressed
                        spacebarPressed = true;
                        platform.extendPlatform();
                    } else if (event.getEventType() == KeyEvent.KEY_RELEASED) {
                        // Spacebar released
                        spacebarPressed = false;
                        platform.stopExtension();
                        platform.rotatePlatform();
                        mainCharacter.moveForward(platform, pillar, scoreKeeper);
//                        pillar.animatePillars();
                    }
                } else if (event.getCode() == KeyCode.DOWN) {
                    mainCharacter.flippingDown();
                }
            }
        };

        FXMLManager.getInstance().getStage().getScene().setOnKeyPressed(keyEventHandler);
        FXMLManager.getInstance().getStage().getScene().setOnKeyReleased(keyEventHandler);
    }

    private void switchScene(String fxmlFileName) throws IOException {
        FXMLManager.getInstance().getStage().setScene(FXMLManager.getInstance().loadFXML(fxmlFileName));
    }
}
