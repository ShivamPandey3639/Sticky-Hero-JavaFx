package com.example.stickhero;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Controller3 {
    private Map<String, Scene> fxmlCaches = new HashMap<>();
    public void DD(String fxmlPath){
        if (fxmlCaches.containsKey(fxmlPath)) {
            fxmlCaches.get(fxmlPath);
        } else {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
                Parent root = loader.load();
                Scene scene = new Scene(root);
                fxmlCaches.put(fxmlPath, scene);

            } catch (IOException e) {
                throw new RuntimeException("Failed to load FXML: " + fxmlPath, e);
            }
        }
    }
}
