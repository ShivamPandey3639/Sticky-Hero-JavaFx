package com.example.stickhero;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

public class FXMLManager extends Application {

    private static FXMLManager instance;// singelton
    private Map<String, Scene> fxmlCache = new HashMap<>();
    private Stage currentStage;
     static String file="in.txt";

    public static FXMLManager getInstance() {
        if (instance == null) {
            instance = new FXMLManager();
        }
        return instance;
    }


    public Scene loadFXML(String fxmlPath) {
        if (fxmlCache.containsKey(fxmlPath)) {
            return fxmlCache.get(fxmlPath);
        } else {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
                Parent root = loader.load();
                Scene scene = new Scene(root);
                fxmlCache.put(fxmlPath, scene);
                return scene;
            } catch (IOException e) {
                throw new RuntimeException("Failed to load FXML: " + fxmlPath, e);
            }
        }
    }

    public Stage getStage() {
        return currentStage;
    }

    public void setStage(Stage stage) {
        this.currentStage = stage;
    }

    @Override
    public void start(Stage primaryStage) throws IOException {
        // You can perform additional initialization if needed
        FXMLManager.getInstance().setStage(primaryStage);
//        setStage(primaryStage);
        loadFXML("HomeScreen.fxml");
        loadFXML("GameScreen.fxml");
        loadFXML("characterOverlay.fxml");
        PrintWriter fp = new PrintWriter(new FileWriter(file));
        fp.println(Score.getPoints());
        fp.close();

        primaryStage.setResizable(false);

        primaryStage.setTitle("Stick Hero");
        primaryStage.setScene(loadFXML("HomeScreen.fxml"));
        primaryStage.show();
    }
}