package com.example.stickhero;

public class FactorySound {
    public SoundInterface getSound(String soundType){//factory methods
        if(soundType == null){
            return null;
        } else if(soundType.equalsIgnoreCase("HomeSound")){
            return new Sound();
        } else if(soundType.equalsIgnoreCase("FallSound")){
            return new Sound();
        } else if(soundType.equalsIgnoreCase("GameOver")){
            return new Sound();
        } else if(soundType.equalsIgnoreCase("VictorySound")){
            return new Sound();
        }
        return null;
    }
}