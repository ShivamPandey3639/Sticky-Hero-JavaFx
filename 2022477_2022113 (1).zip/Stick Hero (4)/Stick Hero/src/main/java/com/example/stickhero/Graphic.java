package com.example.stickyhero;

import javafx.scene.image.Image;

import java.util.List;

public class Graphic {
    private List<Image> graphic;

    public Graphic(List<Image> graphic) {
        this.graphic = graphic;
    }

    public static void addGraphic(Image img){}
}
