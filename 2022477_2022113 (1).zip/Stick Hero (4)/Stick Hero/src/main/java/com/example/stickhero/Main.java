package com.example.stickhero;


public class Main {
    public static void main(String[] args) {
//        launch(args);
        FXMLManager.launch(FXMLManager.class, args);

    }
}