package com.example.stickhero;

import javafx.animation.ParallelTransition;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

import java.util.Random;

public class Pillar {
    final static int MAX_GAP = 600;
    final static int MIN_GAP = 50;
    private static final int PLATFORM_HEIGHT = 200; // Fixed height of the pillar
    private static final int MIN_PLATFORM_WIDTH = 75;
    private static final int MAX_PLATFORM_WIDTH = 300;
    private Rectangle p1;
    private Rectangle p2;
    private Rectangle p3;
    private ImageView character;
    private double position1;
    private double position2;
    @FXML
    private AnchorPane main;


    public Pillar() {
    }

    public Pillar(Rectangle p1, Rectangle p2, Rectangle p3) {
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
        this.position1 = generateRandomGap();
        this.position2 = generateRandomGap();

        p1.setHeight(PLATFORM_HEIGHT);
        p2.setHeight(PLATFORM_HEIGHT);
        p3.setHeight(PLATFORM_HEIGHT);
        p1.setWidth(generateRandomWidth());
        p2.setWidth(generateRandomWidth());
        p3.setWidth(generateRandomWidth());

        p1.setY(600);
        p2.setY(600);
        p3.setY(600);
        p1.setX(200);
        p2.setX(700);
        p3.setX(10000);
        p1.setVisible(true);
        p2.setVisible(true);
        p3.setVisible(false);
    }

    private static TranslateTransition createTranslateTransition(Rectangle pillar, double targetX, double duration) {
        TranslateTransition transition = new TranslateTransition(Duration.seconds(duration), pillar);
        transition.setToX(targetX);
        return transition;
    }

    public Rectangle getP1() {
        return p1;
    }

    public void setP1(Rectangle p1) {
        this.p1 = p1;
    }

    public Rectangle getP2() {
        return p2;
    }

    public void setP2(Rectangle p2) {
        this.p2 = p2;
    }

    public Rectangle getP3() {
        return p3;
    }

    public void setP3(Rectangle p3) {
        this.p3 = p3;
    }

    public double getposition1() {
        return position1;
    }

    public void setposition1(double position1) {
        this.position1 = position1;
    }

    public double getposition2() {
        return position2;
    }

    public void setposition2(double position2) {
        this.position2 = position2;
    }

    private double generateRandomGap() {
        Random random = new Random();
        return random.nextDouble() * (MAX_GAP - MIN_GAP) + MIN_GAP;
    }

    private int generateRandomWidth() {
        // Generate a random width between MIN_PILLAR_WIDTH and MAX_PILLAR_WIDTH
        Random random = new Random();
        return random.nextInt(MAX_PLATFORM_WIDTH - MIN_PLATFORM_WIDTH + 1) + MIN_PLATFORM_WIDTH;
    }

    public void movePillars() {

        double durationInSeconds = 1.0; // Adjust the duration as needed

//        TranslateTransition transition1 = createTranslateTransition(p1, -1050, durationInSeconds);
//        TranslateTransition transition2 = createTranslateTransition(p2, -340, durationInSeconds);
//        TranslateTransition transition3 = createTranslateTransition(p3, -9000, durationInSeconds);

        ParallelTransition parallelTransition = new ParallelTransition();
//        parallelTransition.getChildren().addAll( transition1,transition2, transition3);

        parallelTransition.setOnFinished(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                p1.setWidth(new Random().nextDouble(40, 200));
                p2.setX(new Random().nextDouble(p1.getX(), 1000));
                p2.setWidth(new Random().nextDouble(20, 200));

            }
        });

        parallelTransition.play();
    }
}
