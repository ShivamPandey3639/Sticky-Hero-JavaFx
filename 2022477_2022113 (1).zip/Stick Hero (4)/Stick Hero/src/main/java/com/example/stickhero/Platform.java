package com.example.stickhero;

import javafx.animation.*;
import javafx.scene.shape.Rectangle;
import javafx.scene.transform.Rotate;
import javafx.util.Duration;

public class Platform {
    final static int PLATFORM_WIDTH = 5;
    private int platformWidth;
    private int platformPosition;
    private Pillar pillar;
    private Rectangle platform;
    private boolean spaceBarPressed = false;
    private boolean downArrowPressed = false;
    private boolean hKeyPressed = false;
    private boolean extensionInProgress = false;
    private boolean rotationInProgress = false;
    private boolean translationInProgress = false;
    private Timeline extensionTimeline;

    public Platform(Rectangle platform, Pillar pillar) {
        this.platform = platform;
        platform.setWidth(PLATFORM_WIDTH);
        platform.setHeight(0);
        platform.setX(200);
        platform.setY(600);
        this.pillar = pillar;
    }


    void extendPlatform() {
        if (!extensionInProgress) {
            extensionTimeline = new Timeline(new KeyFrame(Duration.millis(5), e -> {
                platform.setY(platform.getY() - 1);
                platform.setHeight(platform.getHeight() + 1);
            }));
            extensionTimeline.setCycleCount(Timeline.INDEFINITE);
            extensionTimeline.play();
            extensionInProgress = true;
        }
    }

    void stopExtension() {
        if (extensionTimeline != null) {
            extensionTimeline.stop();
            extensionInProgress = false;
        }
    }

    void rotatePlatform() {
        if (!rotationInProgress) {
            double rotateTo = 90; // You can adjust the angle as needed

            Rotate rotate = new Rotate(0, platform.getX() + platform.getWidth() / 2.0, platform.getY() + platform.getHeight());
            platform.getTransforms().add(rotate);

            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(0.34), new KeyValue(rotate.angleProperty(), rotateTo)));

            timeline.setOnFinished(event -> {
                rotationInProgress = false;
            });

            rotationInProgress = true;
            timeline.play();
        }
    }

    private void moveAndResetPlatform() {
    }

    void resetPlatform(Pillar pillar) {
        platform.getTransforms().clear(); // Clear existing transforms
        platform.setWidth(PLATFORM_WIDTH);
        platform.setHeight(0);
        platform.setX(pillar.getP1().getX() + pillar.getP1().getWidth());
        platform.setY(600);
    }

    public double getHeight() {
        return platform.getHeight();
    }

    public double getX() {
        return platform.getX();
    }
}
