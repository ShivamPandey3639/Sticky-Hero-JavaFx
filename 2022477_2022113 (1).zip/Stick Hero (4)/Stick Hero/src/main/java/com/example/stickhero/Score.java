package com.example.stickhero;

import javafx.scene.control.Label;

public class Score {
    public static int getHighScore() {
        return highScore;
    }

    private static int highScore = 0;
    private static int points = 0;
    private static int cherryCount = 0;
    private Label score;
    private Label cherry;

    public Score(Label score, Label cherry) {
        this.score = score;
        this.cherry = cherry;
    }

    public static int getPoints() {
        return points;
    }
    public static int getCherryCount(){return cherryCount;}

    public void updateScore() {
        points++;
        if (points > highScore)
            highScore = points;
        score.setText(String.valueOf(points));
    }

    public void updateCherryCount() {
        cherryCount++;
        cherry.setText(String.valueOf(cherryCount));
    }
}
