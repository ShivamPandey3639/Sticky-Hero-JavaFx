package com.example.stickhero;

import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

import java.io.File;
import java.util.ArrayList;
import java.util.List;


interface SoundInterface {
    void victorySound();
    void fallSound();
    void gameOver();
    void homeSound();
}


//Threading
public class Sound extends Thread implements SoundInterface{
    private Media media;
    private MediaPlayer mediaPlayer;
    private List<File> songs;
    private File[] files;
    private File directory;

    public Sound() {

    }

    @Override
    public void run() {
        songs=new ArrayList<>();
        directory =new File( "sound");
        files=directory.listFiles();
        if(files != null) {

            for(File file : files) {

                songs.add(file);
            }
        }

        media = new Media(songs.get(2).toURI().toString());
        mediaPlayer = new MediaPlayer(media);
        mediaPlayer.play();
    }

    public void homeSound(){
        songs=new ArrayList<>();
        directory =new File( "sound");
        files=directory.listFiles();
        if(files != null) {

            for(File file : files) {

                songs.add(file);
            }
        }

        media = new Media(songs.get(2).toURI().toString());
        mediaPlayer = new MediaPlayer(media);
        mediaPlayer.play();
    }
    public void victorySound(){
        media = new Media(songs.get(songs.size()-1).toURI().toString());
        mediaPlayer = new MediaPlayer(media);
        mediaPlayer.play();
    }
    public void fallSound(){
        media = new Media(songs.get(9).toURI().toString());
        mediaPlayer = new MediaPlayer(media);
        mediaPlayer.play();
    }
    public void gameOver(){
        media = new Media(songs.get(7).toURI().toString());
        mediaPlayer = new MediaPlayer(media);
        mediaPlayer.play();
    }




}
