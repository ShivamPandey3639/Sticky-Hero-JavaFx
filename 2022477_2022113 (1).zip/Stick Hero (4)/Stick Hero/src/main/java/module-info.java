module com.example.stickhero {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires javafx.media;

    opens com.example.stickhero to javafx.fxml;
    exports com.example.stickhero;
    exports com.example.stickyhero;
    opens com.example.stickyhero to javafx.fxml;
}