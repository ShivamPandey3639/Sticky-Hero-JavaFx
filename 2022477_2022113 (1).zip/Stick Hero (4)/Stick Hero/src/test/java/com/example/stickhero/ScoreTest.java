package com.example.stickhero;

import org.junit.Test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import static org.junit.Assert.*;
public class ScoreTest {
    @Test
    public void Test_0() throws IOException {
        BufferedReader in= new BufferedReader(new FileReader("in.txt"));
        boolean val;
        String score = in.readLine();
        if (score != null){
            val = true;
        }else{
            val = false;
        }

        assertTrue(val);
    }
}