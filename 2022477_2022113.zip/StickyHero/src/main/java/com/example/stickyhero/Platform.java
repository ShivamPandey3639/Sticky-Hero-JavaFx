package com.example.stickyhero;

public class Platform {
    private int width;

    public Platform(int width) {
        this.width = width;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }
}
