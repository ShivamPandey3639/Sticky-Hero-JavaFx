package com.example.stickyhero;

public class Score {
    private static int points;

    public Score() {
    }

    public static int getPoints() {
        return points;
    }
    public void updateScore(int no){}
}
