package com.example.stickyhero;

import java.util.List;



public class Sound {
    private List sound;

    public Sound(List sound) {
        this.sound = sound;
    }

    public List getSound() {
        return sound;
    }
    public void addSound(){}

}
